// src/lib/api.ts
import { Product } from "@/types";

const API_URL = process.env.NEXT_PUBLIC_WORDPRESS_API_URL;

export async function fetchGraphQL(query: string, variables?: Record<string, unknown>) {
  if (!API_URL) {
    console.warn("NEXT_PUBLIC_WORDPRESS_API_URL is not defined in .env.local");
    return null;
  }

  const payload = variables ? { query, variables } : { query };

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      next: { revalidate: 60 }, 
      body: JSON.stringify(payload),
    });

    const json = await res.json();

    if (json.errors) {
      console.error('GraphQL Errors:', json.errors);
      throw new Error('Failed to fetch API');
    }

    return json.data;
  } catch (error) {
    console.error("Error fetching from WordPress:", error);
    return null;
  }
}

function parseWooPrice(priceStr?: string): number {
  if (!priceStr) return 0;
  return Number(priceStr.replace(/[^0-9]/g, ""));
}

export async function getCategories() {
  const query = `
    query GetCategories {
      productCategories(first: 100, where: { hideEmpty: true }) {
        nodes {
          name
          slug
        }
      }
    }
  `;

  const data = await fetchGraphQL(query);
  return data?.productCategories?.nodes || [];
}

// Fetch ALL products using Cursor-Based Pagination
export async function getAllProducts(): Promise<Product[]> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let allNodes: any[] = [];
  let hasNextPage = true;
  let afterCursor = null;

  // Keep looping and fetching batches of 100 until WordPress says there are no more pages
  while (hasNextPage) {
    const query = `
      query GetProducts($after: String) {
        products(first: 100, after: $after, where: { status: "publish" }) {
          pageInfo {
            hasNextPage
            endCursor
          }
          nodes {
            id
            databaseId
            name
            slug
            description
            shortDescription
            productCategories {
              nodes {
                name
              }
            }
            image {
              sourceUrl
              altText
            }
            ... on SimpleProduct {
              price
              regularPrice
              salePrice
              stockStatus
              stockQuantity
            }
          }
        }
      }
    `;

    const data = await fetchGraphQL(query, { after: afterCursor });
    const productsData = data?.products;

    if (!productsData) break;

    // Add this batch of 100 products to our master list
    allNodes = [...allNodes, ...(productsData.nodes || [])];
    
    // Check if we need to run the loop again
    hasNextPage = productsData.pageInfo?.hasNextPage || false;
    afterCursor = productsData.pageInfo?.endCursor || null;
  }

  // Now map the complete list of products to our frontend interface
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const mappedProducts: Product[] = allNodes.map((node: any) => {
    const currentPrice = parseWooPrice(node.price);
    const regularPrice = parseWooPrice(node.regularPrice);
    
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const categoryNames = node.productCategories?.nodes?.map((c: any) => c.name).join(", ") || "Uncategorized";

    const rawDescription = node.shortDescription || node.description || "";
    const cleanDescription = rawDescription.replace(/<[^>]*>?/gm, '').trim() || "No description available.";

    return {
      id: node.id || node.databaseId?.toString(),
      name: node.name || "Unknown Product",
      brand: "Kafunda Selection", 
      category: categoryNames,
      price_ugx: currentPrice,
      original_price_ugx: regularPrice > currentPrice ? regularPrice : null,
      image_url: node.image?.sourceUrl || "/don julio.webp",
      gallery_urls: node.image?.sourceUrl ? [node.image.sourceUrl] : [],
      in_stock: node.stockStatus === "IN_STOCK",
      is_sale: !!node.salePrice,
      description: cleanDescription,
      abv: "N/A",
      volume: "750ml",
      stock_count: node.stockQuantity || 5,
    };
  });

  // Deduplicate products just in case WPGraphQL sent duplicates
  const uniqueProducts = Array.from(
    new Map(mappedProducts.map((p) => [p.id, p])).values()
  );

  return uniqueProducts;
}

export async function getProductBySlug(id: string): Promise<Product | null> {
  const query = `
    query GetProductById($id: ID!) {
      product(id: $id, idType: ID) {
        id
        databaseId
        name
        slug
        description
        shortDescription
        productCategories {
          nodes {
            name
          }
        }
        image {
          sourceUrl
        }
        galleryImages {
          nodes {
            sourceUrl
          }
        }
        ... on SimpleProduct {
          price
          regularPrice
          stockStatus
          stockQuantity
        }
      }
    }
  `;

  const data = await fetchGraphQL(query, { id });
  
  if (!data?.product) return null;
  
  const node = data.product;
  const currentPrice = parseWooPrice(node.price);
  const regularPrice = parseWooPrice(node.regularPrice);
  
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const gallery = node.galleryImages?.nodes?.map((img: any) => img.sourceUrl) || [];
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const categoryNames = node.productCategories?.nodes?.map((c: any) => c.name).join(", ") || "Uncategorized";
  
  const rawDescription = node.shortDescription || node.description || "";
  const cleanDescription = rawDescription.replace(/<[^>]*>?/gm, '').trim() || "No description available.";

  return {
    id: node.id || node.databaseId?.toString(),
    name: node.name || "Unknown Product",
    brand: "Kafunda Selection",
    category: categoryNames,
    price_ugx: currentPrice,
    original_price_ugx: regularPrice > currentPrice ? regularPrice : null,
    image_url: node.image?.sourceUrl || "/don julio.webp",
    gallery_urls: gallery.length > 0 ? gallery : (node.image?.sourceUrl ? [node.image.sourceUrl] : []),
    in_stock: node.stockStatus === "IN_STOCK",
    is_sale: !!node.regularPrice && currentPrice < regularPrice,
    description: cleanDescription,
    abv: "N/A",
    volume: "750ml",
    stock_count: node.stockQuantity || 5,
  };
}

// Add these interfaces right above the createOrder function
export interface CheckoutFormData {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

// Update the function signature to use the new interfaces instead of "any"
export async function createOrder(customerData: CheckoutFormData, cartItems: CartItem[]) {
  const lineItems = cartItems.map(item => {
    const decodedId = typeof window !== 'undefined' ? atob(item.product.id) : Buffer.from(item.product.id, 'base64').toString('utf-8');
    const databaseId = parseInt(decodedId.split(':')[1] || decodedId.replace(/[^0-9]/g, ''));
    
    return {
      productId: databaseId || parseInt(item.product.id), 
      quantity: item.quantity
    };
  });

  const mutation = `
    mutation Checkout($input: CheckoutInput!) {
      checkout(input: $input) {
        result
        order {
          databaseId
          orderKey
          status
          total
        }
        redirect
      }
    }
  `;

  const variables = {
    input: {
      clientMutationId: "kafunda_checkout",
      billing: {
        firstName: customerData.firstName,
        lastName: customerData.lastName,
        phone: customerData.phone,
        email: customerData.email,
        address1: customerData.address,
        city: customerData.city,
        country: "UG", 
      },
      shipping: {
        firstName: customerData.firstName,
        lastName: customerData.lastName,
        address1: customerData.address,
        city: customerData.city,
        country: "UG",
      },
      lineItems: lineItems,
      paymentMethod: "cod", 
      isPaid: false,
    }
  };

  const data = await fetchGraphQL(mutation, variables);
  
  if (!data?.checkout) {
    throw new Error("Failed to process checkout");
  }
  
  return data.checkout.order;
}