"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { ShieldCheck, Loader2 } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { formatUGX } from "@/lib/utils";
import { createOrder, CheckoutFormData, CartItem } from "@/lib/api";

export default function CheckoutPage() {
    // We bypass strict TS here temporarily to safely map whichever 
    // naming convention your specific CartContext uses.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const cart = useCart() as any;
    
    // Safely assign the array and total to match our strong types
    const items: CartItem[] = cart.cartItems || cart.items || [];
    const totalPrice: number = cart.cartTotal || cart.totalPrice || 0;
    const clearCart = cart.clearCart;

    const router = useRouter();
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // Form State mapped strictly to our CheckoutFormData type
    const [formData, setFormData] = useState<CheckoutFormData>({
        firstName: "",
        lastName: "",
        phone: "",
        email: "",
        address: "",
        city: "Kampala",
    });

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError(null);

        try {
            // Send the order to WordPress
            const order = await createOrder(formData, items);
            
            if (order) {
                // Success! Clear the cart and go to a success page
                if (clearCart) clearCart();
                router.push(`/checkout/success?orderId=${order.databaseId}`);
            }
        } catch (err) {
            console.error(err);
            setError("There was a problem processing your order. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    if (items.length === 0) {
        return (
            <div className="min-h-[60vh] flex flex-col items-center justify-center bg-gray-50">
                <h1 className="text-2xl font-black uppercase tracking-tighter mb-4">Your cart is empty</h1>
                <p className="text-zinc-500 mb-8">Add some drinks before checking out.</p>
                <Link href="/shop" className="bg-primary-red text-white px-8 py-4 font-bold uppercase tracking-widest text-sm transition-colors hover:bg-black">
                    Return to Shop
                </Link>
            </div>
        );
    }

    return (
        <div className="bg-gray-50 min-h-screen py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <h1 className="text-3xl md:text-4xl font-black uppercase tracking-tighter mb-8">
                    Secure Checkout
                </h1>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                    {/* Left: Delivery Details Form */}
                    <div className="lg:col-span-7 space-y-8">
                        <form id="checkout-form" onSubmit={handleSubmit} className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
                            <h2 className="text-xl font-black uppercase tracking-widest mb-6 border-b border-gray-100 pb-4">Delivery Information</h2>
                            
                            {error && (
                                <div className="bg-red-50 text-red-600 p-4 rounded-md mb-6 text-sm font-bold">
                                    {error}
                                </div>
                            )}

                            <div className="grid grid-cols-2 gap-6 mb-6">
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">First Name *</label>
                                    <input required type="text" name="firstName" value={formData.firstName} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:ring-2 focus:ring-primary-red focus:outline-none" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Last Name *</label>
                                    <input required type="text" name="lastName" value={formData.lastName} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:ring-2 focus:ring-primary-red focus:outline-none" />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-6 mb-6">
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Phone Number *</label>
                                    <input required type="tel" name="phone" value={formData.phone} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:ring-2 focus:ring-primary-red focus:outline-none" placeholder="07XX XXX XXX" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Email Address</label>
                                    <input type="email" name="email" value={formData.email} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:ring-2 focus:ring-primary-red focus:outline-none" />
                                </div>
                            </div>

                            <div className="mb-6">
                                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Delivery Address / Location *</label>
                                <input required type="text" name="address" value={formData.address} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:ring-2 focus:ring-primary-red focus:outline-none" placeholder="E.g., Muyenga, Tank Hill Rd, near the supermarket" />
                            </div>

                            <div className="mb-6">
                                <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">City/Area *</label>
                                <select name="city" value={formData.city} onChange={handleInputChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-md focus:ring-2 focus:ring-primary-red focus:outline-none font-medium">
                                    <option value="Kampala">Kampala</option>
                                    <option value="Entebbe">Entebbe</option>
                                    <option value="Wakiso">Wakiso</option>
                                    <option value="Mukono">Mukono</option>
                                </select>
                            </div>

                            <div className="pt-6 border-t border-gray-100">
                                <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Payment Method</h3>
                                <div className="p-4 border-2 border-primary-red bg-red-50/50 rounded-md flex items-start space-x-3">
                                    <div className="w-4 h-4 rounded-full bg-primary-red mt-1 shrink-0"></div>
                                    <div>
                                        <p className="font-bold text-zinc-900 text-sm">Cash / Mobile Money on Delivery</p>
                                        <p className="text-xs text-zinc-500 mt-1">Pay comfortably when your drinks arrive at your door.</p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    {/* Right: Order Summary */}
                    <div className="lg:col-span-5">
                        <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 sticky top-24">
                            <h2 className="text-xl font-black uppercase tracking-widest mb-6 border-b border-gray-100 pb-4">Order Summary</h2>
                            
                            <div className="space-y-4 mb-6 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
                                {/* Correctly typed CartItem map */}
                                {items.map((item: CartItem) => (
                                    <div key={item.product.id} className="flex items-center space-x-4">
                                        <div className="relative w-16 h-16 bg-gray-50 rounded-md border border-gray-100 shrink-0">
                                            <Image src={item.product.image_url} alt={item.product.name} fill className="object-contain p-2" />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-bold text-zinc-900 truncate">{item.product.name}</p>
                                            <p className="text-xs text-zinc-500 font-medium">Qty: {item.quantity}</p>
                                        </div>
                                        <p className="text-sm font-black">{formatUGX(item.product.price_ugx * item.quantity)}</p>
                                    </div>
                                ))}
                            </div>

                            <div className="border-t border-gray-100 pt-4 space-y-3 mb-8">
                                <div className="flex justify-between text-sm">
                                    <span className="text-zinc-500 font-medium">Subtotal</span>
                                    <span className="font-bold">{formatUGX(totalPrice)}</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span className="text-zinc-500 font-medium">Delivery</span>
                                    <span className="font-bold text-success-green">Calculated on call</span>
                                </div>
                                <div className="flex justify-between text-xl border-t border-gray-100 pt-4">
                                    <span className="font-black uppercase tracking-widest">Total</span>
                                    <span className="font-black text-primary-red">{formatUGX(totalPrice)}</span>
                                </div>
                            </div>

                            <button
                                type="submit"
                                form="checkout-form"
                                disabled={isLoading}
                                className="w-full bg-primary-red hover:bg-primary-red-hover text-white py-4 px-8 font-bold text-sm tracking-widest uppercase transition-all shadow-lg flex items-center justify-center space-x-2 disabled:opacity-70 disabled:cursor-not-allowed"
                            >
                                {isLoading ? (
                                    <>
                                        <Loader2 className="h-5 w-5 animate-spin" />
                                        <span>Processing...</span>
                                    </>
                                ) : (
                                    <span>Place Order</span>
                                )}
                            </button>

                            <div className="mt-6 flex items-center justify-center space-x-2 text-xs text-zinc-400 font-medium">
                                <ShieldCheck className="h-4 w-4" />
                                <span>256-Bit Secure SSL Checkout</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}