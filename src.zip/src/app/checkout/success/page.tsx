"use client";

import React, { Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { CheckCircle2, ArrowRight } from "lucide-react";

function SuccessContent() {
    const searchParams = useSearchParams();
    const orderId = searchParams.get("orderId");

    return (
        <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 text-center bg-white animate-in fade-in zoom-in duration-500">
            <CheckCircle2 className="h-24 w-24 text-success-green mb-6" />
            <h1 className="text-4xl md:text-5xl font-black uppercase tracking-tighter mb-4">
                Order Confirmed!
            </h1>
            <p className="text-zinc-500 text-lg mb-2">
                Thank you for shopping with Kafunda.
            </p>
            {orderId && (
                <p className="text-zinc-800 font-bold mb-8">
                    Your Order ID is: <span className="text-primary-red">#{orderId}</span>
                </p>
            )}
            
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-100 max-w-md w-full mb-8 text-sm text-zinc-600 font-medium">
                <p>Our team is preparing your drinks right now.</p>
                <p className="mt-2">We will call you shortly on the phone number provided to confirm the exact delivery location and fee.</p>
            </div>

            <Link href="/shop" className="inline-flex items-center space-x-2 bg-black text-white px-8 py-4 font-bold uppercase tracking-widest text-xs transition-colors hover:bg-gray-800 rounded-full shadow-lg">
                <span>Continue Shopping</span>
                <ArrowRight className="h-4 w-4" />
            </Link>
        </div>
    );
}

export default function CheckoutSuccessPage() {
    return (
        <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
            <SuccessContent />
        </Suspense>
    );
}