import { MetadataRoute } from 'next';
import { SITE } from '@/lib/constants';

export default function robots(): MetadataRoute.Robots {
    return {
        rules: {
            userAgent: '*',
            allow: '/',
            disallow: ['/checkout', '/api/'],
        },
        sitemap: `${SITE.url}/sitemap.xml`,
    };
}
